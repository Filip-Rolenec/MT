from gas_example.optimization.adp_algorithm import adp_algorithm_complete

if __name__ == "__main__":
    adp_algorithm_complete()
